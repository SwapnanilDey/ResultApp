package com.example.result;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class createnote extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createnote);
    }
}