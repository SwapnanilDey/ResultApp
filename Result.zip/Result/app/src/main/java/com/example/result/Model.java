package com.example.result;

public class Model {
    String name,phy,chem,mathematics;

    public String getName() {
        return name;
    }

    public String getPhy() {
        return phy;
    }

    public String getChem() {
        return chem;
    }

    public String getMathematics() {
        return mathematics;
    }

}
